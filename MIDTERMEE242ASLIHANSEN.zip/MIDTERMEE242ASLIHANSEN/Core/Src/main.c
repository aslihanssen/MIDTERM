#include "stm32f4xx.h"

// Define the timer number, LED pin number, and duration
#define TIMERNUMBER     13
#define LEDPINNUMBER    14
#define DURATION        9780
#define ARRNUMBER       65535

int main(void)
{
    // Enable the GPIO D
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;

    // Set GPIO D pin 14 as output
    GPIOD->MODER |= GPIO_MODER_MODE14_0;

    // Clock the gate of Timer 13
    RCC->APB1ENR |= RCC_APB1ENR_TIM13EN;

    // Initialize the timer
    TIM13->PSC = 2;
    TIM13->ARR = ARRNUMBER;

    while (1)
    {
        // Start the timer
        TIM13->CR1 |= TIM_CR1_CEN;

        // Wait until the timer reaches the duration
        while (TIM13->CNT < DURATION);

        // Stop the timer and reset the count register
        TIM13->CR1 &= ~TIM_CR1_CEN;
        TIM13->CNT = 1;

        // Toggle the LED
        GPIOD->ODR ^= (1 << LEDPINNUMBER);
    }
}
